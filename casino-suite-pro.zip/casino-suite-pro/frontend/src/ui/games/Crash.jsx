import React, { useState, useRef, useLayoutEffect } from 'react'
import rocketURL from '../../assets/svg/crash/rocket.svg'
import flameURL from '../../assets/svg/crash/flame.svg'
export default function Crash({onDone}){
  const api=window.CASINO_API
  const [stake,setStake]=useState(1)
  const [auto,setAuto]=useState(2.0)
  const [res,setRes]=useState(null)
  const [isFlying,setIsFlying]=useState(false)
  const [currentMultiplier,setCurrentMultiplier]=useState(1.0)
  const [flightTime,setFlightTime]=useState(0)
  const [cashedOut,setCashedOut]=useState(false)
  const [cashoutMultiplier,setCashoutMultiplier]=useState(null)
  const [showExplosion,setShowExplosion]=useState(false)
  const [gameRef, setGameRef] = useState(null)
  const [gameData, setGameData] = useState(null)
  
  // SVG trail refs and state
  const containerRef = useRef(null)
  const [trailPoints, setTrailPoints] = useState({ x0: 0, y0: 0, x1: 0, y1: 0 })
  
  // === physics + drawing refs ===
  const rafRef = useRef(0)
  const startMsRef = useRef(0)         // server start time (ms) or now()
  const kRef = useRef(0)               // exponential rate so m(t)=e^(k t)
  const crashMRef = useRef(2.0)        // crash multiplier (server)
  const tCrashRef = useRef(8)          // seconds to crash (derived)
  const skewRef = useRef(0)            // optional server/client skew

  // adaptive y-scale: visual top multiplier (smoothly follows current m)
  const yMaxRef = useRef(1000.0)  // start at 1000x for logarithmic scale
  const yLagRef = useRef(1000.0)  // for label/lines easing (optional)

  // trail & particles
  const trailRef = useRef([])          // Array<[x,y]>
  const [pathD, setPathD] = useState("")         // SVG path for curve
  const [rocketPose, setRocketPose] = useState({ x:0, y:0, angle:0 })
  const [canCashout, setCanCashout] = useState(false)

  // particle explosion
  const partsRef = useRef([])          // {x,y,vx,vy,life,ttl,size}
  
  // smooth rotation
  const angleRef = useRef(0)
  const crashedRef = useRef(false)       // Track if game has crashed
  const gameRefRef = useRef(null)        // Store game reference for cashout
  
  // Set the fixed launch point once (10% from left, 20px from bottom)
  useLayoutEffect(() => {
    if (containerRef.current) {
      const el = containerRef.current
      const rect = el.getBoundingClientRect()
      setTrailPoints(p => ({
        ...p,
        x0: rect.width * 0.10,
        y0: rect.height - 20
      }))
    }
  }, [])
  
  
  // screen mapping (SVG overlays the container; we read size per frame)
  const maxTime = 14;      // seconds across the X axis
  const Y_TOP   = 20.0;    // fixed top of the screen (20x)
  const VISUAL_SLOPE = 1/3; // 0.333... → draw 1/3 as tall
  
  // Fixed visual physics (independent of crash multiplier)
  const GRAVITY = 0.02;   // tweak for curve steepness
  const VERTICAL_SCALE = 0.05; // tweak to control rise speed
  const FIXED_K = 0.15; // fixed rate for UI counter growth (independent of crash outcome)

  function mkScales(rect) {
    const padL=36, padR=56, padT=20, padB=36;
    const innerW = rect.width  - padL - padR;
    const innerH = rect.height - padT - padB;
    const xPx = (t)=> padL + (Math.min(t, maxTime)/maxTime) * innerW;
    // Linear map: 1..Y_TOP → bottom..top (no clamp here)
    const yPx = (m)=> {
      const mClamped = Math.max(1.0, Math.min(Y_TOP, m));
      const r = (mClamped - 1.0) / (Y_TOP - 1.0);
      return padT + innerH - r * innerH;
    };
    return { padL, padT, innerW, innerH, xPx, yPx };
  }

  // exponential model. k is chosen so e^(k * tCrash) == mCrash
  const mOfT = (t)=> Math.exp(kRef.current * Math.max(0, t))
  const nowMs = ()=> performance.now()
  
  // smooth rotation helper to prevent jittering
  function smoothAngle(prevDeg, nextDeg, alpha = 0.25){
    // shortest-path interpolation (avoid 360° wrap snapping)
    let delta = ((nextDeg - prevDeg + 540) % 360) - 180;
    return prevDeg + delta * alpha;
  }

  // Smoothly follow current multiplier with some headroom (logarithmic scale)
  function updateYMax(currentM) {
    const minTop   = 10.0;                // never show less than 10x (log scale)
    const headroom = 1.5;                 // keep 50% more space above rocket (log scale)
    const target   = Math.max(minTop, currentM * headroom);
    
    // Cap at 1000x for the top of the chart
    const maxTop = 1000.0;
    const finalTarget = Math.min(target, maxTop);

    const follow   = 0.15;                // how quickly the top chases the target
    yMaxRef.current += (finalTarget - yMaxRef.current) * follow;

    // Optional: separate easing for tick labels/grid, so numbers glide more slowly
    const labelFollow = 0.10;
    yLagRef.current  += (yMaxRef.current - yLagRef.current) * labelFollow;
  }

  function spawnExplosion(x, y){
    const arr = partsRef.current
    for (let i=0;i<28;i++){
      const a = Math.random()*Math.PI*2
      const v = 120 + Math.random()*120
      arr.push({ x, y, vx:Math.cos(a)*v, vy:Math.sin(a)*v, life:0, ttl:0.6+Math.random()*0.3, size:3+Math.random()*3 })
    }
  }

  function stepParticles(dt){
    const arr = partsRef.current
    for (const p of arr){
      p.life += dt
      p.x += p.vx*dt; p.y += p.vy*dt
      p.vx *= 0.96; p.vy *= 0.96
    }
    for (let i=arr.length-1;i>=0;i--) if (arr[i].life>arr[i].ttl) arr.splice(i,1)
  }

  function buildPath(points){
    if (!points.length) return ""
    let d = `M${points[0][0]} ${points[0][1]}`
    for (let i=1;i<points.length;i++) d += ` L${points[i][0]} ${points[i][1]}`
    return d
  }

  const cashOut = async () => {
    if (isFlying && !cashedOut) {
      setCashedOut(true)
      setCashoutMultiplier(currentMultiplier)
      // Mark as manual cashout (will be handled in the timeout)
      window.manualCashout = { cashedOut: true, multiplier: currentMultiplier }
      
      // Show win message immediately
      setRes({
        success: true,
        payout: stake * currentMultiplier,
        result: {
          manual_cashed_out: true,
          manual_cashout_multiplier: currentMultiplier
        }
      });
      
      // Call cashout API to credit wallet
      try {
        const response = await fetch(`${api}/api/casino/crash/cashout`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-User-Id': 'demo-user'
          },
          body: JSON.stringify({
            ref: gameRef,
            multiplier: currentMultiplier
          })
        })
        const result = await response.json()
        if (response.ok) {
          // Update payout with actual credited amount
          if (gameData) {
            gameData.payout = result.payout
            setGameData({...gameData})
          }
          // Refresh balance after credit
          onDone && onDone()
        }
      } catch (error) {
        console.error('Cashout error:', error)
      }
    }
  }
  
  const play= async()=>{
    // Reset all refs first to prevent old state interference
    crashedRef.current = false
    startMsRef.current = nowMs()
    
    setIsFlying(true)
    setCurrentMultiplier(1.0)
    setFlightTime(0)
    setRes(null)
    setCashedOut(false)
    setCashoutMultiplier(null)
    setShowExplosion(false)
    setCanCashout(true)        // Enable cashout for new game
    
    // Get the crash result from backend first (this debits wallet)
    const r = await fetch(`${api}/api/casino/crash/play`, {method:'POST', headers:{'Content-Type':'application/json','X-User-Id':'demo-user'}, body: JSON.stringify({stake, currency:'USD', params:{auto_cashout:auto}})})
    const j = await r.json()
    const actualCrashMultiplier = j.result?.multiplier || 1.01
    
    // Store game reference and data for cashout
    setGameRef(j.ref)
    setGameData(j)
    gameRefRef.current = j.ref  // Store in ref for RAF loop access
    
    // Refresh balance after wallet debit
    onDone && onDone()
    
    crashMRef.current = actualCrashMultiplier
    // Choose either:
    // 1) fixed visual crash time, derive k so exp(k*tCrash)=mCrash:
    tCrashRef.current = Math.min(12, 8 + Math.random()*2)       // ~8–10s feel
    kRef.current = Math.log(crashMRef.current) / tCrashRef.current

    // start time (server authoritative if you have one)
    startMsRef.current = nowMs()

    setIsFlying(true)
    setShowExplosion(false)
    trailRef.current = []
    partsRef.current = []
    yMaxRef.current = 2.0

    const loop = (ts)=>{
      const container = containerRef.current
      if (!container){ rafRef.current = requestAnimationFrame(loop); return }
      const rect = container.getBoundingClientRect()

      // time & multiplier
      const t = Math.max(0, (ts - startMsRef.current - skewRef.current)/1000)
      
      // 1. Compute the server crash time in seconds based on parabola
      const mCrash = crashMRef.current;   // from server
      const tCrash = maxTime * Math.sqrt((mCrash - 1) / (Y_TOP - 1));

      // 2. Check if crashed
      const crashed = t >= tCrash;

      // 3. Counter pacing along parabola (capped at crash time)
      const sUi = Math.min(1, t / maxTime);
      const mUi = 1 + (Y_TOP - 1) * (sUi * sUi);

      // 4. Displayed multiplier freezes at crash
      const displayM = crashed ? mCrash : mUi;

      // 5. Check for auto cashout
      if (!crashed && !crashedRef.current && auto && displayM >= auto) {
        // Trigger auto cashout
        setCashedOut(true);
        setCashoutMultiplier(auto);
        window.manualCashout = { cashedOut: true, multiplier: auto };
        
        // Show win message immediately
        setRes({
          success: true,
          payout: stake * auto,
          result: {
            auto_cashed_out: true,
            auto_cashout_multiplier: auto
          }
        });
        
        // Call cashout API to credit wallet
        fetch(`${api}/api/casino/crash/cashout`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-User-Id': 'demo-user'
          },
          body: JSON.stringify({
            ref: gameRefRef.current,
            multiplier: auto
          })
        }).then(response => response.json())
        .then(data => {
          console.log('Auto cashout successful:', data);
          // Refresh balance
          onDone && onDone();
        }).catch(error => {
          console.error('Auto cashout error:', error);
        });
        
        // Stop the RAF loop
        if (rafRef.current) {
          cancelAnimationFrame(rafRef.current);
          rafRef.current = 0;
        }
        return; // Exit the loop
      }

      // 6. Disable cashout button immediately when crashed
      if (crashed && !crashedRef.current) {
        crashedRef.current = true;
        setCanCashout(false);
        
        // Show explosion for 1 second, then show loss message
        setShowExplosion(true);
        setTimeout(() => {
          setShowExplosion(false);
          setRes({
            success: false,
            payout: 0,
            result: {
              crashed: true,
              crash_multiplier: mCrash
            }
          });
        }, 1000);
        
        // Stop the RAF loop when crashed
        if (rafRef.current) {
          cancelAnimationFrame(rafRef.current);
          rafRef.current = 0;
        }
      }

      // Build scales with fixed top = 20x
      const { xPx, yPx } = mkScales(rect);

      // Effective visible time = min(elapsed, crash time)
      const tVis = Math.min(t, tCrash);

      // Parabola y = 1 + (Y_TOP - 1) * (s^2), where s = t/maxTime
      // Guarantees y(0)=1 and y(maxTime)=Y_TOP (i.e., top-right corner = 20x)
      const steps = 80;
      const pts = [];
      for (let i=0;i<=steps;i++){
        const ti = (i/steps) * tVis;
        const s  = Math.max(0, Math.min(1, ti / maxTime));
        const yDraw = 1.0 + (Y_TOP - 1.0) * (s * s);
        pts.push([ xPx(ti), yPx(yDraw) ]);
      }

      // save curve path for SVG
      setPathD(buildPath(pts))

      // rocket pose from last segment (tangent)
      const [x2,y2] = pts[pts.length-1] || [xPx(0), yPx(1)]
      const [x1,y1] = pts[pts.length-2] || [x2-1, y2]
      const ang = Math.atan2(-(y2 - y1), (x2 - x1)) * 180/Math.PI
      const base = 90 // initial offset of 90 degrees clockwise
      const target = -ang + base // negative ang for counterclockwise rotation
      const smoothed = smoothAngle(angleRef.current, target, 0.25)
      angleRef.current = smoothed
      setRocketPose({ x:x2, y:y2, angle: smoothed })

      // trail: keep last N rocket positions
      const tr = trailRef.current
      tr.push([x2,y2]); if (tr.length>180) tr.shift()

      // particles (during crash)
      const dt = Math.min(0.033, (rafRef.current ? (ts - (rafRef.prevTs||ts))/1000 : 0))
      rafRef.prevTs = ts
      stepParticles(dt)

      // expose real multiplier for UI/payouts (clamp to crash for display)
      setCurrentMultiplier(displayM)

      // 5. Explosion trigger
      if (crashed && !showExplosion){
        setShowExplosion(true)
        spawnExplosion(x2,y2) // rocket's position at this exact crash point
      }
      
      // Finish round when crashed and particles are gone
      if (crashed && partsRef.current.length===0){
        // finish round when particles are gone
        setIsFlying(false)
        setFlightTime(0)
        // decide result/cashout
        if (window.manualCashout?.cashedOut){
          j.payout = stake * window.manualCashout.multiplier
          j.result = { ...j.result, manual_cashed_out:true, manual_cashout_multiplier: window.manualCashout.multiplier }
          window.manualCashout = null
        } else {
          j.payout = 0
        }
        setRes({ ...j, result:{...j.result, multiplier: crashMRef.current } })
        onDone&&onDone()
        return
      }

      rafRef.current = requestAnimationFrame(loop)
    }
    rafRef.current = requestAnimationFrame(loop)
  }
  return <div className="space-y-8">
    <div className="text-center mb-8">
      <h2 className="text-5xl font-bold text-shadow-gold text-yellow-400 mb-4 animate-glow-pulse casino-title">
        🚀 CRASH ROYALE 🚀
      </h2>
      <div className="text-xl text-yellow-300 opacity-90 font-semibold">Ride the Rocket • Cash Out Before the Crash</div>
    </div>
    
    <div className="flex gap-8 items-center justify-center p-8 glass-effect rounded-3xl neon-glow">
      <div className="flex flex-col items-center gap-3">
        <label className="text-yellow-400 font-bold text-sm uppercase tracking-widest">Bet Amount</label>
        <input 
          type="number" 
          value={stake} 
          onChange={e=>setStake(+e.target.value)} 
          className="input w-36 text-center text-2xl font-bold" 
          placeholder="$20" 
        />
      </div>
      
      <div className="flex flex-col items-center gap-3">
        <label className="text-yellow-400 font-bold text-sm uppercase tracking-widest">Auto Cashout</label>
        <input 
          type="number" 
          step="0.1" 
          value={auto} 
          onChange={e=>setAuto(+e.target.value)} 
          className="input w-36 text-center text-2xl font-bold" 
          placeholder="2.0x" 
        />
      </div>
      
      <button 
        onClick={play} 
        className="btn text-2xl px-12 py-6 bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-500 hover:to-orange-500 text-white border-2 border-red-400"
        style={{minWidth: '200px'}}
      >
        <span className="flex items-center gap-3">
          <div className="text-3xl animate-bounce">🚀</div>
          <span className="font-black">LAUNCH</span>
        </span>
      </button>
      
      {/* Live Stake Display and Cashout Button */}
      {isFlying && !cashedOut && (
        <div className="flex flex-col items-center gap-3">
          <label className="text-green-400 font-bold text-sm uppercase tracking-widest">Current Value</label>
          <div className="balance-display text-3xl font-black text-green-400 animate-pulse">
            ${(stake * currentMultiplier).toFixed(2)}
          </div>
            <button 
              onClick={cashOut}
              disabled={crashedRef.current}
              className={`btn text-xl px-8 py-4 text-white border-2 ${
                crashedRef.current 
                  ? 'bg-gradient-to-r from-red-600 to-red-700 border-red-400' 
                  : 'bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 border-green-400 animate-pulse'
              }`}
            >
            💰 CASH OUT 💰
          </button>
        </div>
      )}
      
      
    </div>
    
    {/* Win/Loss Banner at Top - OUTSIDE main container */}
    {!isFlying && res && (
      <div className={`fixed top-0 left-0 right-0 z-50 p-4 text-center ${
        res.payout > 0 
          ? 'bg-gradient-to-r from-green-600 to-emerald-600' 
          : 'bg-gradient-to-r from-red-600 to-red-700'
      }`}>
        <div className="text-2xl font-black text-white">
          {res.result?.auto_cashed_out ? '✅ AUTO CASHOUT TRIGGERED! ✅' :
           res.result?.manual_cashed_out ? '🎯 MANUAL CASHOUT SUCCESS! 🎯' : 
           res.payout > 0 ? '🎉 SUCCESSFUL FLIGHT! 🎉' : '💥 ROCKET CRASHED! 💥'}
        </div>
        <div className="text-lg font-bold text-white">
          {res.payout > 0 
            ? `${(res.result?.auto_cashout_multiplier || res.result?.manual_cashout_multiplier || res.result?.multiplier || 0).toFixed(2)}x - You won $${res.payout.toFixed(2)}!`
            : `Crashed at ${(res?.result?.multiplier || 0).toFixed(2)}x - You lost $${stake.toFixed(2)}`
          }
        </div>
      </div>
    )}
    
    {/* Rocket Flight Animation Area */}
    {isFlying && (
      <div 
        ref={containerRef}
        style={{
          position: 'relative',
          height: '800px',
          background: 'linear-gradient(to bottom, #1e3a8a, #581c87)',
          borderRadius: '24px',
          border: '4px solid #eab308',
          overflow: 'hidden',
          margin: '20px 0'
        }}>
        {/* SVG Chart + Trail + Rocket */}
        <svg width="100%" height="100%" style={{ position:'absolute', inset:0, zIndex:1 }}>
          <defs>
            <linearGradient id="trailGrad" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#a987ff" stopOpacity="0"/>
              <stop offset="100%" stopColor="#c9b7ff" stopOpacity="1"/>
            </linearGradient>
            <filter id="glow">
              <feGaussianBlur stdDeviation="3" result="b"/>
              <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
            </filter>
          </defs>

          {/* curve */}
          <path d={pathD} fill="none" stroke="url(#trailGrad)" strokeWidth="4" filter="url(#glow)"/>

          {/* rocket */}
          <g transform={`translate(${rocketPose.x},${rocketPose.y}) rotate(${rocketPose.angle})`}>
            {/* flame below the body */}
            <image href={flameURL} x="-16" y="-42" width="32" height="48" opacity="0.9"/>
            <image href={rocketURL} x="-24" y="-24" width="48" height="48"/>
          </g>

          {/* trailing polyline (softer) */}
          {trailRef.current.length>1 && (
            <path
              d={`M${trailRef.current.map(p=>p.join(' ')).join(' L')}`}
              fill="none"
              stroke="url(#trailGrad)"
              strokeWidth="4"
              filter="url(#glow)"
              opacity="0.85"
            />
          )}

          {/* particles */}
          {partsRef.current.map((p,i)=>{
            const a = 1 - (p.life/p.ttl)
            const hue = 38 + 10*(1-a)
            return <circle key={i} cx={p.x} cy={p.y} r={p.size*(0.7+0.6*a)}
              fill={`hsla(${hue},95%,60%,${a})`} />
          })}
        </svg>
        
        {/* Multiplier Display */}
        <div style={{
          position: 'absolute',
          top: '30px',
          left: '50%',
          transform: 'translateX(-50%)',
          fontSize: '48px',
          fontWeight: 'bold',
          color: '#fbbf24',
          textShadow: '2px 2px 4px rgba(0,0,0,0.8)'
        }}>
          {currentMultiplier.toFixed(2)}x
        </div>
        
        {/* Explosion Animation */}
        {showExplosion && (
          <div style={{
            position: 'absolute',
            bottom: `${20 + Math.min(currentMultiplier * 35, 380) + 40}px`,
            left: `${Math.min(10 + currentMultiplier * 8, 60)}%`,
            transform: 'translate(-50%, 50%)',
            fontSize: '120px',
            animation: 'explosion 3s ease-out',
            zIndex: 10,
            display: 'none'
          }}>
            💥
          </div>
        )}
        
        {/* Additional explosion effects during crash */}
        {showExplosion && (
          <>
            <div style={{
              position: 'absolute',
              bottom: `${20 + Math.min(currentMultiplier * 35, 380) + 40}px`,
              left: `${Math.min(10 + currentMultiplier * 8, 60)}%`,
              transform: 'translate(-50%, 50%)',
              fontSize: '80px',
              animation: 'explosion 3s ease-out 0.2s',
              zIndex: 9,
              opacity: 0.8,
              display: 'none'
            }}>
              💥
            </div>
            <div style={{
              position: 'absolute',
              bottom: `${20 + Math.min(currentMultiplier * 35, 380) + 40}px`,
              left: `${Math.min(10 + currentMultiplier * 8, 60)}%`,
              transform: 'translate(-50%, 50%)',
              fontSize: '60px',
              animation: 'explosion 3s ease-out 0.4s',
              zIndex: 8,
              opacity: 0.6,
              display: 'none'
            }}>
              💥
            </div>
          </>
        )}
        
        {/* Stars Background */}
        <div style={{
          position: 'absolute',
          top: '10%',
          left: '10%',
          width: '4px',
          height: '4px',
          backgroundColor: 'white',
          borderRadius: '50%',
          opacity: 0.8
        }}></div>
        <div style={{
          position: 'absolute',
          top: '20%',
          right: '15%',
          width: '3px',
          height: '3px',
          backgroundColor: 'white',
          borderRadius: '50%',
          opacity: 0.6
        }}></div>
        <div style={{
          position: 'absolute',
          top: '40%',
          left: '20%',
          width: '2px',
          height: '2px',
          backgroundColor: 'white',
          borderRadius: '50%',
          opacity: 0.7
        }}></div>
        <div style={{
          position: 'absolute',
          top: '60%',
          right: '25%',
          width: '3px',
          height: '3px',
          backgroundColor: 'white',
          borderRadius: '50%',
          opacity: 0.5
        }}></div>
        <div style={{
          position: 'absolute',
          top: '15%',
          left: '70%',
          width: '2px',
          height: '2px',
          backgroundColor: 'white',
          borderRadius: '50%',
          opacity: 0.8
        }}></div>
      </div>
    )}
    
    {res && <div className="relative p-8 bg-gradient-to-br from-red-900/50 to-orange-900/50 rounded-3xl border-4 border-red-500 shadow-2xl overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-red-500/20 to-orange-500/20 animate-pulse"></div>
      <div className="relative z-10 text-center">
        <div className="text-3xl font-bold text-yellow-400 mb-6 text-shadow-gold">
          {res.result?.auto_cashed_out ? '🎯 AUTO CASHOUT RESULT 🎯' :
           res.result?.manual_cashed_out ? '🎯 CASHOUT RESULT 🎯' :
           '🚀 CRASH RESULT 🚀'}
        </div>
        
        <div className="mb-8">
          <div className={`text-8xl font-black mb-4 ${
            res.result?.multiplier >= 2 ? 'text-green-400 animate-pulse-win' : 
            res.result?.multiplier >= 1.5 ? 'text-yellow-400' : 'text-red-400'
          }`}>
            {/* Show the relevant multiplier based on what actually happened */}
            {res.result?.auto_cashed_out ? (res.result.auto_cashout_multiplier || 0).toFixed(2) + 'x' :
             res.result?.manual_cashed_out ? (res.result.manual_cashout_multiplier || 0).toFixed(2) + 'x' :
             (res.result?.multiplier || 0).toFixed(2) + 'x'}
          </div>
          
          {res.result?.auto_cashed_out && (
            <div className="space-y-2">
              <div className="text-2xl text-green-400 font-bold bg-green-900/30 rounded-xl p-4 inline-block border-2 border-green-400">
                ✅ Auto Cashout: {res.result.auto_cashout_multiplier?.toFixed(2)}x
              </div>
              <div className="text-lg text-gray-400 font-semibold">
                💥 Would have crashed at: {res.result?.multiplier?.toFixed(2)}x
              </div>
            </div>
          )}
          
          {res.result?.manual_cashed_out && (
            <div className="text-2xl text-blue-400 font-bold bg-blue-900/30 rounded-xl p-4 inline-block border-2 border-blue-400">
              🎯 Manual Cashout: {res.result.manual_cashout_multiplier?.toFixed(2)}x
            </div>
          )}
        </div>
        
        <div className={`text-4xl font-black p-6 rounded-2xl ${
          res.payout > 0 ? 'text-green-400 bg-green-900/30 animate-pulse-win' : 'text-red-400 bg-red-900/30'
        }`}>
          {res.result?.auto_cashed_out ? '✅ AUTO CASHOUT TRIGGERED! ✅' :
           res.result?.manual_cashed_out ? '🎯 MANUAL CASHOUT SUCCESS! 🎯' : 
           res.payout > 0 ? '🎉 SUCCESSFUL FLIGHT! 🎉' : '💥 ROCKET CRASHED! 💥'}
        </div>
        
        {res.result?.multiplier >= 5 && (
          <div className="text-6xl font-black text-yellow-400 text-shadow-gold animate-jackpot mt-6">
            🌟 HIGH MULTIPLIER! 🌟
          </div>
        )}
      </div>
      
      <div className="absolute top-4 right-4 text-6xl animate-ball-bounce">
        {res.payout > 0 ? '🚀' : '💥'}
      </div>
    </div>}
    
    <div className="grid grid-cols-4 gap-4 text-center text-yellow-300">
      <div className="glass-effect p-4 rounded-xl hover:scale-105 transition-transform duration-300">
        <div className="text-3xl mb-2">🚀</div>
        <div className="font-semibold">Low Risk</div>
        <div className="text-green-400 font-bold">1.2x - 2.0x</div>
      </div>
      <div className="glass-effect p-4 rounded-xl hover:scale-105 transition-transform duration-300">
        <div className="text-3xl mb-2">⭐</div>
        <div className="font-semibold">Medium Risk</div>
        <div className="text-yellow-400 font-bold">2.0x - 5.0x</div>
      </div>
      <div className="glass-effect p-4 rounded-xl hover:scale-105 transition-transform duration-300">
        <div className="text-3xl mb-2">🔥</div>
        <div className="font-semibold">High Risk</div>
        <div className="text-orange-400 font-bold">5.0x - 10.0x</div>
      </div>
      <div className="glass-effect p-4 rounded-xl hover:scale-105 transition-transform duration-300">
        <div className="text-3xl mb-2">💎</div>
        <div className="font-semibold">Extreme Risk</div>
        <div className="text-red-400 font-bold">10.0x+</div>
      </div>
    </div>
  </div>
}

