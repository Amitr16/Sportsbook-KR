import React, { useState, useMemo } from 'react'
import BlackjackAdvanced from '../../components/BlackjackAdvanced'

// Import card images so Vite can handle the hashing
import backImage from '../../assets/png/back.png'

// Import all card images
import aceOfClubs from '../../assets/png/ace_of_clubs.png'
import aceOfDiamonds from '../../assets/png/ace_of_diamonds.png'
import aceOfHearts from '../../assets/png/ace_of_hearts.png'
import aceOfSpades from '../../assets/png/ace_of_spades.png'
import jackOfClubs from '../../assets/png/jack_of_clubs.png'
import jackOfDiamonds from '../../assets/png/jack_of_diamonds.png'
import jackOfHearts from '../../assets/png/jack_of_hearts.png'
import jackOfSpades from '../../assets/png/jack_of_spades.png'
import queenOfClubs from '../../assets/png/queen_of_clubs.png'
import queenOfDiamonds from '../../assets/png/queen_of_diamonds.png'
import queenOfHearts from '../../assets/png/queen_of_hearts.png'
import queenOfSpades from '../../assets/png/queen_of_spades.png'
import kingOfClubs from '../../assets/png/king_of_clubs.png'
import kingOfDiamonds from '../../assets/png/king_of_diamonds.png'
import kingOfHearts from '../../assets/png/king_of_hearts.png'
import kingOfSpades from '../../assets/png/king_of_spades.png'

// Import number cards
import twoOfClubs from '../../assets/png/2_of_clubs.png'
import twoOfDiamonds from '../../assets/png/2_of_diamonds.png'
import twoOfHearts from '../../assets/png/2_of_hearts.png'
import twoOfSpades from '../../assets/png/2_of_spades.png'
import threeOfClubs from '../../assets/png/3_of_clubs.png'
import threeOfDiamonds from '../../assets/png/3_of_diamonds.png'
import threeOfHearts from '../../assets/png/3_of_hearts.png'
import threeOfSpades from '../../assets/png/3_of_spades.png'
import fourOfClubs from '../../assets/png/4_of_clubs.png'
import fourOfDiamonds from '../../assets/png/4_of_diamonds.png'
import fourOfHearts from '../../assets/png/4_of_hearts.png'
import fourOfSpades from '../../assets/png/4_of_spades.png'
import fiveOfClubs from '../../assets/png/5_of_clubs.png'
import fiveOfDiamonds from '../../assets/png/5_of_diamonds.png'
import fiveOfHearts from '../../assets/png/5_of_hearts.png'
import fiveOfSpades from '../../assets/png/5_of_spades.png'
import sixOfClubs from '../../assets/png/6_of_clubs.png'
import sixOfDiamonds from '../../assets/png/6_of_diamonds.png'
import sixOfHearts from '../../assets/png/6_of_hearts.png'
import sixOfSpades from '../../assets/png/6_of_spades.png'
import sevenOfClubs from '../../assets/png/7_of_clubs.png'
import sevenOfDiamonds from '../../assets/png/7_of_diamonds.png'
import sevenOfHearts from '../../assets/png/7_of_hearts.png'
import sevenOfSpades from '../../assets/png/7_of_spades.png'
import eightOfClubs from '../../assets/png/8_of_clubs.png'
import eightOfDiamonds from '../../assets/png/8_of_diamonds.png'
import eightOfHearts from '../../assets/png/8_of_hearts.png'
import eightOfSpades from '../../assets/png/8_of_spades.png'
import nineOfClubs from '../../assets/png/9_of_clubs.png'
import nineOfDiamonds from '../../assets/png/9_of_diamonds.png'
import nineOfHearts from '../../assets/png/9_of_hearts.png'
import nineOfSpades from '../../assets/png/9_of_spades.png'
import tenOfClubs from '../../assets/png/10_of_clubs.png'
import tenOfDiamonds from '../../assets/png/10_of_diamonds.png'
import tenOfHearts from '../../assets/png/10_of_hearts.png'
import tenOfSpades from '../../assets/png/10_of_spades.png'

// Card image mapping
const cardImages = {
  'A♠': aceOfSpades, 'A♥': aceOfHearts, 'A♦': aceOfDiamonds, 'A♣': aceOfClubs,
  '2♠': twoOfSpades, '2♥': twoOfHearts, '2♦': twoOfDiamonds, '2♣': twoOfClubs,
  '3♠': threeOfSpades, '3♥': threeOfHearts, '3♦': threeOfDiamonds, '3♣': threeOfClubs,
  '4♠': fourOfSpades, '4♥': fourOfHearts, '4♦': fourOfDiamonds, '4♣': fourOfClubs,
  '5♠': fiveOfSpades, '5♥': fiveOfHearts, '5♦': fiveOfDiamonds, '5♣': fiveOfClubs,
  '6♠': sixOfSpades, '6♥': sixOfHearts, '6♦': sixOfDiamonds, '6♣': sixOfClubs,
  '7♠': sevenOfSpades, '7♥': sevenOfHearts, '7♦': sevenOfDiamonds, '7♣': sevenOfClubs,
  '8♠': eightOfSpades, '8♥': eightOfHearts, '8♦': eightOfDiamonds, '8♣': eightOfClubs,
  '9♠': nineOfSpades, '9♥': nineOfHearts, '9♦': nineOfDiamonds, '9♣': nineOfClubs,
  '10♠': tenOfSpades, '10♥': tenOfHearts, '10♦': tenOfDiamonds, '10♣': tenOfClubs,
  'J♠': jackOfSpades, 'J♥': jackOfHearts, 'J♦': jackOfDiamonds, 'J♣': jackOfClubs,
  'Q♠': queenOfSpades, 'Q♥': queenOfHearts, 'Q♦': queenOfDiamonds, 'Q♣': queenOfClubs,
  'K♠': kingOfSpades, 'K♥': kingOfHearts, 'K♦': kingOfDiamonds, 'K♣': kingOfClubs,
};

// Helper function to convert card string to image filename
const getCardImage = (cardStr) => {
  // Handle card back (dealer's hole card)
  if (cardStr === '🂠' || cardStr === 'back' || !cardStr || cardStr.trim() === '') {
    return backImage;
  }
  
  // Return the mapped image or fallback to back image
  return cardImages[cardStr] || backImage;
};

// Helper function to calculate card value
const getCardValue = (cardStr) => {
  if (!cardStr || cardStr === '🂠' || cardStr.trim() === '') return 0;
  const value = cardStr.replace(/[♠♥♦♣SHDC]/g, '').trim();
  if (value === 'A') return 11;
  if (['J','Q','K'].includes(value)) return 10;
  return parseInt(value) || 0;
};

// Helper function to calculate hand total (with proper ace handling)
const getHandTotal = (cards) => {
  if (!cards || !Array.isArray(cards)) return 0;
  
  let value = 0;
  let aces = 0;
  
  for (const card of cards) {
    if (!card || card === '🂠' || card.trim() === '') continue;
    
    const rank = card.replace(/[♠♥♦♣SHDC]/g, '').trim();
    if (rank === 'A') {
      aces += 1;
      value += 11;
    } else if (['J','Q','K'].includes(rank)) {
      value += 10;
    } else {
      value += parseInt(rank) || 0;
    }
  }
  
  // Adjust for aces (convert 11 to 1 if over 21)
  while (value > 21 && aces > 0) {
    value -= 10;
    aces -= 1;
  }
  
  return value;
};
export default function Blackjack({onDone}){
  const api = window.CASINO_API
  const headers={'Content-Type':'application/json','X-User-Id':'demo-user'}
  const [stake,setStake]=useState(5)
  const [state,setState]=useState(null)
  const [res,setRes]=useState(null)
  const [dealingCards,setDealingCards]=useState(false)
  const call = async(action)=>{
    if(action === 'deal') {
      setDealingCards(true)
      // Show placeholder cards immediately
      setState({
        player: ['🂠', '🂠'],
        dealer: ['🂠', '🂠'],
        pv: 0,
        dv: 0
      })
      setTimeout(() => setDealingCards(false), 2000)
    }
    
    const body = {stake, currency:'USD', action, state, params:{ref:state?.ref}}
    const r = await fetch(`${api}/api/casino/blackjack/play`, {method:'POST', headers: {...headers, 'Content-Type':'application/json'}, credentials: 'include', body: JSON.stringify(body)})
    const j = await r.json(); setRes(j); setState(j.result)
    
    // Refresh balance when there's a wallet transaction or when game ends with payout
    if (action === 'deal' || action === 'double' || (j.result?.final && j.payout > 0)) {
      console.log('💰 Blackjack: Refreshing balance due to wallet transaction or win')
      // Add small delay to ensure backend has processed the wallet update
      setTimeout(() => {
        onDone && onDone()
      }, 500)
    }
  }
  const allowed = useMemo(()=>{
    const s = state||{}
    const final = s.final
    const can = {hit:false, stand:false, double:false, split:false, insurance:false, surrender:false}
    if(!s.player || final) return can
    const pv = s.pv||0
    can.hit = pv<21
    can.stand = true
    can.double = s.player?.length===2
    can.split = s.player?.length===2 && s.player[0]===s.player[1]
    can.insurance = (s.dealer && s.dealer[0]==='A' && s.player?.length===2)
    can.surrender = s.player?.length===2
    return can
  },[state])
  return (
    <div className="space-y-8">
      <div className="text-center mb-8">
        <h2 className="text-5xl font-bold text-shadow-gold text-yellow-400 mb-4 animate-glow-pulse casino-title">
          🂡 BLACKJACK ROYALE 🂡
        </h2>
        <div className="text-xl text-yellow-300 opacity-90 font-semibold">Beat the Dealer • Get 21</div>
      </div>
      
      <div className="flex gap-8 items-center justify-center p-8 glass-effect rounded-3xl neon-glow flex-wrap">
        <div className="flex flex-col items-center gap-3">
          <label className="text-yellow-400 font-bold text-sm uppercase tracking-widest">Bet Amount</label>
          <input 
            type="number" 
            min="1" 
            value={stake} 
            onChange={e=>setStake(parseFloat(e.target.value||'1'))} 
            className="input w-36 text-center text-2xl font-bold" 
            placeholder="$25" 
          />
        </div>
        
        <button 
          onClick={()=>call('deal')} 
          className="btn-primary text-2xl px-12 py-6"
          style={{minWidth: '200px'}}
        >
          <span className="flex items-center gap-3">
            <div className="text-3xl">🂡</div>
            <span className="font-black">DEAL CARDS</span>
          </span>
        </button>
        
        <BlackjackAdvanced allowed={allowed} onAction={name=>call(name)}/>
        
        <div className="flex flex-col items-center gap-3">
          <label className="text-yellow-400 font-bold text-sm uppercase tracking-widest">Total Win</label>
          <div className={`balance-display text-3xl font-black ${res?.payout > 0 ? 'animate-pulse-win' : ''}`}>
            ${res?.payout?.toFixed(2)||'0.00'}
          </div>
        </div>
      </div>
      
      {/* Always show the table - dealer area visible even when empty */}
      <div className="casino-felt p-8 rounded-3xl border-4 border-yellow-600 shadow-2xl">
        <div className="space-y-12">
          {/* Dealer Section - Top of Table - Always Visible */}
          <div className="text-center relative">
            <div className="absolute inset-0 bg-gradient-to-b from-green-900/20 to-transparent rounded-2xl"></div>
            <div className="relative z-10 p-6">
              <div className="text-yellow-400 font-bold text-3xl mb-6 text-shadow-gold flex items-center justify-center gap-3">
                <span>🎩</span> DEALER <span>🎩</span>
              </div>
              <div className="flex gap-3 justify-center mb-6 flex-wrap min-h-[160px] items-center">
                {state?.dealer && Array.isArray(state.dealer) ? (
                  state.dealer.map((card, i) => (
                    <div 
                      key={i} 
                      className="playing-card"
                      style={{
                        width: '100px',
                        height: '140px',
                        borderRadius: '15px',
                        boxShadow: '0 12px 24px rgba(0,0,0,0.4), 0 0 0 1px rgba(255,255,255,0.8)',
                        transform: 'perspective(1000px) rotateY(0deg)',
                        animation: dealingCards ? `dealCard 0.6s ease-out ${i * 0.3}s both` : 'none',
                        transition: 'transform 0.3s ease, box-shadow 0.3s ease',
                        position: 'relative',
                        overflow: 'hidden'
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.transform = 'perspective(1000px) rotateY(-10deg) translateY(-8px)'
                        e.currentTarget.style.boxShadow = '0 16px 32px rgba(0,0,0,0.5), 0 0 0 1px rgba(255,255,255,0.9)'
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.transform = 'perspective(1000px) rotateY(0deg) translateY(0px)'
                        e.currentTarget.style.boxShadow = '0 12px 24px rgba(0,0,0,0.4), 0 0 0 1px rgba(255,255,255,0.8)'
                      }}
                    >
                      <img 
                        src={getCardImage(card)}
                        alt={card}
                        style={{
                          width: '100%',
                          height: '100%',
                          objectFit: 'cover',
                          borderRadius: '12px'
                        }}
                        onError={(e) => {
                          // Fallback to card back if image not found
                          e.target.src = backImage;
                        }}
                      />
                    </div>
                  ))
                ) : (
                  <div className="text-gray-500 text-lg italic">
                    Dealer's cards will appear here
                  </div>
                )}
              </div>
              {state?.dealer && (
                <div className="text-white font-bold text-xl bg-black/50 rounded-xl p-3 inline-block">
                  Total: <span className="text-yellow-400 text-2xl">
                    {state.final ? (state.dv || getHandTotal(state.dealer)) : getHandTotal(state.dealer)}
                  </span>
                </div>
              )}
            </div>
          </div>
        
          {/* Player Section - Bottom of Table - Only show when cards are dealt */}
          {state && (
            <div className="text-center relative">
              <div className="absolute inset-0 bg-gradient-to-t from-blue-900/20 to-transparent rounded-2xl"></div>
              <div className="relative z-10 p-6">
                <div className="text-yellow-400 font-bold text-3xl mb-6 text-shadow-gold flex items-center justify-center gap-3">
                  <span>👤</span> YOUR HAND <span>👤</span>
                </div>
                <div className="flex gap-3 justify-center mb-6 flex-wrap">
                  {state.player?.map((card, i) => (
                    <div 
                      key={i} 
                      className="playing-card"
                      style={{
                        width: '100px',
                        height: '140px',
                        borderRadius: '15px',
                        boxShadow: '0 12px 24px rgba(0,0,0,0.4), 0 0 0 1px rgba(255,255,255,0.8)',
                        transform: 'perspective(1000px) rotateY(0deg)',
                        animation: dealingCards ? `dealCard 0.6s ease-out ${(i + 2) * 0.3}s both` : 'none',
                        transition: 'transform 0.3s ease, box-shadow 0.3s ease',
                        position: 'relative',
                        overflow: 'hidden'
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.transform = 'perspective(1000px) rotateY(-10deg) translateY(-8px)'
                        e.currentTarget.style.boxShadow = '0 16px 32px rgba(0,0,0,0.5), 0 0 0 1px rgba(255,255,255,0.9)'
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.transform = 'perspective(1000px) rotateY(0deg) translateY(0px)'
                        e.currentTarget.style.boxShadow = '0 12px 24px rgba(0,0,0,0.4), 0 0 0 1px rgba(255,255,255,0.8)'
                      }}
                    >
                      <img 
                        src={getCardImage(card)}
                        alt={card}
                        style={{
                          width: '100%',
                          height: '100%',
                          objectFit: 'cover',
                          borderRadius: '12px'
                        }}
                        onError={(e) => {
                          // Fallback to card back if image not found
                          e.target.src = backImage;
                        }}
                      />
                    </div>
                  ))}
                </div>
                <div className="text-white font-bold text-xl bg-black/50 rounded-xl p-3 inline-block">
                  Total: <span className="text-yellow-400 text-2xl">{state.pv}</span>
                </div>
              </div>
            </div>
          )}
        </div>
      
        {state?.final && (
          <div className="text-center mt-8">
            <div className={`text-4xl font-black p-6 rounded-2xl ${
              res?.payout > 0 ? 'text-green-400 bg-green-900/30 animate-pulse-win' : 'text-red-400 bg-red-900/30'
            }`}>
              {res?.payout > 0 ? '🎉 YOU WIN! 🎉' : '💔 DEALER WINS 💔'}
            </div>
            {state.pv === 21 && state.player?.length === 2 && (
              <div className="text-6xl font-black text-yellow-400 text-shadow-gold animate-jackpot mt-4">
                ♠️ BLACKJACK! ♠️
              </div>
            )}
          </div>
        )}
      </div>
      
      <div className="grid grid-cols-4 gap-4 text-center text-yellow-300">
        <div className="glass-effect p-4 rounded-xl hover:scale-105 transition-transform duration-300">
          <div className="text-3xl mb-2">🂡</div>
          <div className="font-semibold">Blackjack</div>
          <div className="text-yellow-400 font-bold">3:2 Payout</div>
        </div>
        <div className="glass-effect p-4 rounded-xl hover:scale-105 transition-transform duration-300">
          <div className="text-3xl mb-2">🃏</div>
          <div className="font-semibold">Regular Win</div>
          <div className="text-yellow-400 font-bold">1:1 Payout</div>
        </div>
        <div className="glass-effect p-4 rounded-xl hover:scale-105 transition-transform duration-300">
          <div className="text-3xl mb-2">🤝</div>
          <div className="font-semibold">Push</div>
          <div className="text-yellow-400 font-bold">Bet Returned</div>
        </div>
        <div className="glass-effect p-4 rounded-xl hover:scale-105 transition-transform duration-300">
          <div className="text-3xl mb-2">💥</div>
          <div className="font-semibold">Bust</div>
          <div className="text-red-400 font-bold">Lose Bet</div>
        </div>
      </div>
    </div>
  )
}
