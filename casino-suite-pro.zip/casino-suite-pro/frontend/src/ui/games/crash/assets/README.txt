Add your preferred UI font as font.woff2 here and @font-face it in styles.css.
