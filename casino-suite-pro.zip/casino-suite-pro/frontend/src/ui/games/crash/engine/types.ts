// Crash game engine types and adapter API
export type CrashPhase = 'waiting' | 'flying' | 'crashed';

export type CrashEvents = {
  onPayout: (multiplier: number) => void;           // every frame m(t)
  onPhase: (phase: CrashPhase) => void;
  onCrash: (crashMultiplier: number) => void;
  onCashout: (multiplier: number) => void;
};

export type CrashEngine = {
  setAutoCashout(multiplier: number): void;
  setBetAmount(amount: number): void;
  startRound(seed: string, serverStartMs: number, targetMultiplier?: number): void;
  cashout(): void;
  destroy(): void;
  isActive(): boolean;
  getCurrentMultiplier(): number;
};

export type CrashConfig = {
  mount: HTMLElement;
  assets: Record<string, string>;
  onEvents?: Partial<CrashEvents>;
};

export type CrashRound = {
  seed: string;
  serverStartMs: number;
  targetMultiplier?: number;
  isActive: boolean;
  currentMultiplier: number;
  autoCashoutAt?: number;
};
