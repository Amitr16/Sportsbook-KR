import React, { useState, useEffect } from 'react'
import { API_BASE_URL } from '../config.js'
import Blackjack from './games/Blackjack'
import Baccarat from './games/Baccarat'
import Slots from './games/Slots'
import Crash from './games/Crash'
import RoulettePro from './games/RoulettePro'
import GameHistory from '../components/GameHistory'

const TABS=[
  {key:'roulette-pro', label:'🎡 Roulette'},
  {key:'blackjack', label:'🂡 Blackjack'},
  {key:'baccarat', label:'🂢 Baccarat'},
  {key:'slots', label:'🎰 Slots'},
  {key:'crash', label:'🚀 Crash'}
]

export default function App(){
  const [tab,setTab]=useState('roulette-pro')
  const api = API_BASE_URL
  const [balance, setBalance] = useState(null)
  const [userInfo, setUserInfo] = useState(null)
  const [showHistory, setShowHistory] = useState(false)
  const [balanceSparkle, setBalanceSparkle] = useState(false)
  const [previousBalance, setPreviousBalance] = useState(null)

  const refreshBalance = async ()=>{
    try {
      const r = await fetch(`${api}/api/casino/wallet/balance`, {
        credentials: 'include' // Include session cookies
      })
      if(r.ok){ 
        const newBalance = await r.json()
        
        // Check if balance increased (winning money)
        if (previousBalance && newBalance.balance > previousBalance.balance) {
          console.log('💰 Balance increased! Triggering sparkle animation')
          setBalanceSparkle(true)
          // Stop sparkle after 3 seconds
          setTimeout(() => setBalanceSparkle(false), 3000)
        }
        
        setPreviousBalance(newBalance) // Store the new balance as previous for next comparison
        setBalance(newBalance)
      } else { 
        setBalance({balance: 1000, currency: 'USD'})
        setPreviousBalance(null)
      }
    } catch(e) {
      console.error(e)
      setBalance({balance: 1000, currency: 'USD'})
      setPreviousBalance(null)
    }
  }

  const refreshUserInfo = async ()=>{
    try {
      console.log('🔍 Fetching user info from:', `${api}/api/casino/user/info`)
      console.log('🔍 Current URL:', window.location.href)
      console.log('🔍 Document cookies:', document.cookie)
      
      const r = await fetch(`${api}/api/casino/user/info`, {
        credentials: 'include', // Include session cookies
        headers: {
          'Content-Type': 'application/json'
        }
      })
      
      console.log('🔍 Response status:', r.status)
      console.log('🔍 Response headers:', Object.fromEntries(r.headers.entries()))
      
      if(r.ok){ 
        const userData = await r.json()
        setUserInfo(userData)
        console.log('✅ User info loaded:', userData)
      } else { 
        const errorData = await r.json()
        console.log('❌ Failed to load user info:', r.status, errorData)
        setUserInfo({username: 'Guest', email: 'guest@example.com'})
      }
    } catch(e) { 
      console.error('❌ Error loading user info:', e)
      setUserInfo({username: 'Guest', email: 'guest@example.com'})
    }
  }

  useEffect(()=>{ 
    refreshBalance()
    refreshUserInfo()
  },[])

  return (
    <>
      <style>{`
        @keyframes sparklePulse {
          0% { 
            box-shadow: 0 0 50px rgba(255, 215, 0, 1), 0 0 100px rgba(255, 255, 0, 0.8), 0 0 150px rgba(255, 215, 0, 0.6);
            transform: scale(1.05);
          }
          100% { 
            box-shadow: 0 0 80px rgba(255, 215, 0, 1), 0 0 150px rgba(255, 255, 0, 1), 0 0 200px rgba(255, 215, 0, 0.8);
            transform: scale(1.1);
          }
        }
        
        @keyframes sparkleRotate {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        
        @keyframes sparkleFloat {
          0% { 
            opacity: 1;
            transform: translate(-50%, -50%) scale(0.8);
          }
          50% { 
            opacity: 0.8;
            transform: translate(-50%, -60%) scale(1.2);
          }
          100% { 
            opacity: 0;
            transform: translate(-50%, -80%) scale(1.5);
          }
        }
      `}</style>
      <div style={{
        minHeight: '100vh',
        padding: '32px',
        background: `
          radial-gradient(ellipse at top, rgba(139, 69, 19, 0.3) 0%, transparent 50%),
          radial-gradient(ellipse at bottom, rgba(218, 165, 32, 0.2) 0%, transparent 50%),
          linear-gradient(135deg, #0a0a0a 0%, #1a0f0a 25%, #2a1810 50%, #1a0f0a 75%, #0a0a0a 100%)
        `,
        backgroundAttachment: 'fixed',
        fontFamily: "'Cinzel', serif",
        color: 'white'
      }}>
      <div style={{ maxWidth: '1400px', margin: '0 auto' }}>
        <header style={{
          background: `
            linear-gradient(135deg, rgba(139, 69, 19, 0.9) 0%, rgba(218, 165, 32, 0.95) 25%, rgba(255, 215, 0, 1) 50%, rgba(218, 165, 32, 0.95) 75%, rgba(139, 69, 19, 0.9) 100%),
            radial-gradient(ellipse at center, rgba(255, 255, 255, 0.1) 0%, transparent 70%)
          `,
          border: '4px solid transparent',
          backgroundClip: 'padding-box',
          boxShadow: `
            0 0 50px rgba(255, 215, 0, 0.6),
            inset 0 4px 20px rgba(255, 255, 255, 0.3),
            inset 0 -4px 20px rgba(0, 0, 0, 0.4),
            0 20px 60px rgba(0, 0, 0, 0.5)
          `,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: '32px',
          padding: '32px',
          borderRadius: '24px',
          position: 'relative',
          overflow: 'hidden',
          animation: 'floating 3s ease-in-out infinite'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            <div style={{ 
              fontSize: '4rem',
              animation: 'glow-pulse 2s ease-in-out infinite alternate'
            }}>🎰</div>
            <div>
              <h1 style={{
                fontFamily: "'Playfair Display', serif",
                fontSize: '3.5rem',
                fontWeight: '900',
                textShadow: `
                  3px 3px 6px rgba(0, 0, 0, 0.9),
                  0 0 30px rgba(255, 215, 0, 0.8),
                  0 0 60px rgba(255, 215, 0, 0.5)
                `,
                background: 'linear-gradient(45deg, #FFD700, #FFA500, #FF8C00, #FFD700)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text',
                margin: 0
              }}>
                KRYZEL CASINO
              </h1>
              <div style={{
                color: '#000',
                fontWeight: 'bold',
                fontSize: '1.125rem',
                opacity: 0.8
              }}>Royal Gaming Experience</div>
            </div>
          </div>
          <div style={{ display: 'flex', gap: '24px', alignItems: 'center' }}>
            {/* User Info Display */}
            <div style={{
              fontSize: '1rem',
              fontWeight: 'bold',
              color: '#00FF00',
              background: 'rgba(0, 0, 0, 0.8)',
              padding: '12px 24px',
              border: '2px solid #00FF00',
              borderRadius: '20px',
              boxShadow: '0 0 30px rgba(0, 255, 0, 0.6)',
              textShadow: '2px 2px 4px rgba(0, 0, 0, 0.8)'
            }}>
              👤 {userInfo?.username || 'Guest'} ({userInfo?.email || 'guest@example.com'})
            </div>
            <div style={{
              fontSize: '1.25rem',
              fontWeight: 'bold',
              color: '#FFD700',
              background: 'rgba(0, 0, 0, 0.8)',
              padding: '12px 24px',
              border: '2px solid #FFD700',
              borderRadius: '20px',
              boxShadow: balanceSparkle 
                ? '0 0 50px rgba(255, 215, 0, 1), 0 0 100px rgba(255, 255, 0, 0.8), 0 0 150px rgba(255, 215, 0, 0.6)'
                : '0 0 30px rgba(255, 215, 0, 0.6)',
              textShadow: '2px 2px 4px rgba(0, 0, 0, 0.8)',
              position: 'relative',
              overflow: 'hidden',
              transition: 'all 0.5s ease',
              transform: balanceSparkle ? 'scale(1.05)' : 'scale(1)',
              animation: balanceSparkle ? 'sparklePulse 0.5s ease-in-out infinite alternate' : 'none'
            }}>
              {balanceSparkle && (
                <div style={{
                  position: 'absolute',
                  top: '-10px',
                  left: '-10px',
                  right: '-10px',
                  bottom: '-10px',
                  background: 'radial-gradient(circle, rgba(255, 255, 0, 0.3) 0%, transparent 70%)',
                  animation: 'sparkleRotate 2s linear infinite',
                  pointerEvents: 'none'
                }} />
              )}
              {balanceSparkle && (
                <div style={{
                  position: 'absolute',
                  top: '50%',
                  left: '50%',
                  transform: 'translate(-50%, -50%)',
                  fontSize: '2rem',
                  animation: 'sparkleFloat 1s ease-out infinite',
                  pointerEvents: 'none'
                }}>
                  ✨💰✨
                </div>
              )}
              💰 ${balance?.balance || '1000'}
            </div>
            <button
              onClick={() => setShowHistory(true)}
              style={{
                background: 'rgba(0, 0, 0, 0.8)',
                border: '2px solid #FFD700',
                color: '#FFD700',
                padding: '12px 24px',
                borderRadius: '20px',
                fontWeight: 'bold',
                cursor: 'pointer',
                transition: 'all 0.3s ease',
                boxShadow: '0 0 30px rgba(255, 215, 0, 0.6)',
                textShadow: '2px 2px 4px rgba(0, 0, 0, 0.8)'
              }}
              onMouseEnter={(e) => {
                e.target.style.background = 'rgba(255, 215, 0, 0.2)';
                e.target.style.borderColor = '#FFA500';
                e.target.style.boxShadow = '0 0 40px rgba(255, 215, 0, 0.8)';
              }}
              onMouseLeave={(e) => {
                e.target.style.background = 'rgba(0, 0, 0, 0.8)';
                e.target.style.borderColor = '#FFD700';
                e.target.style.boxShadow = '0 0 30px rgba(255, 215, 0, 0.6)';
              }}
            >
              📝 History
            </button>
            <a style={{
              background: 'rgba(0, 0, 0, 0.8)',
              border: '2px solid #FFD700',
              color: '#FFD700',
              padding: '12px 24px',
              borderRadius: '20px',
              textDecoration: 'none',
              fontWeight: 'bold',
              transition: 'all 0.3s ease',
              boxShadow: '0 0 30px rgba(255, 215, 0, 0.6)',
              textShadow: '2px 2px 4px rgba(0, 0, 0, 0.8)',
              display: 'inline-block'
            }} 
            href="/sportsbook"
            onMouseEnter={(e) => {
              e.target.style.background = 'rgba(255, 215, 0, 0.2)';
              e.target.style.borderColor = '#FFA500';
              e.target.style.boxShadow = '0 0 40px rgba(255, 215, 0, 0.8)';
            }}
            onMouseLeave={(e) => {
              e.target.style.background = 'rgba(0, 0, 0, 0.8)';
              e.target.style.borderColor = '#FFD700';
              e.target.style.boxShadow = '0 0 30px rgba(255, 215, 0, 0.6)';
            }}>
              ← Sportsbook
            </a>
          </div>
        </header>
        
        <nav style={{
          display: 'flex',
          gap: '12px',
          marginBottom: '32px',
          flexWrap: 'wrap',
          justifyContent: 'center',
          padding: '16px',
          background: 'rgba(0, 0, 0, 0.4)',
          backdropFilter: 'blur(10px)',
          border: '1px solid rgba(255, 215, 0, 0.3)',
          borderRadius: '16px',
          boxShadow: '0 0 40px rgba(255, 215, 0, 0.3)'
        }}>
          {TABS.map(t=>(
            <button 
              key={t.key} 
              onClick={()=>setTab(t.key)}
              style={{
                fontFamily: "'Cinzel', serif",
                fontSize: '1.125rem',
                fontWeight: '600',
                padding: '12px 24px',
                borderRadius: '12px',
                border: tab === t.key ? '2px solid #FFD700' : '2px solid rgba(255, 215, 0, 0.3)',
                background: tab === t.key 
                  ? 'linear-gradient(135deg, #FFD700 0%, #FFA500 50%, #FF8C00 100%)'
                  : 'rgba(0, 0, 0, 0.3)',
                color: tab === t.key ? '#000' : '#FFD700',
                cursor: 'pointer',
                transition: 'all 0.3s ease',
                boxShadow: tab === t.key 
                  ? '0 0 30px rgba(255, 215, 0, 0.6)'
                  : '0 4px 15px rgba(0, 0, 0, 0.3)',
                textShadow: tab === t.key ? 'none' : '1px 1px 2px rgba(0, 0, 0, 0.8)'
              }}
              onMouseEnter={(e) => {
                if (tab !== t.key) {
                  e.target.style.background = 'rgba(255, 215, 0, 0.1)';
                  e.target.style.transform = 'scale(1.05)';
                }
              }}
              onMouseLeave={(e) => {
                if (tab !== t.key) {
                  e.target.style.background = 'rgba(0, 0, 0, 0.3)';
                  e.target.style.transform = 'scale(1)';
                }
              }}
            >
              {t.label}
            </button>
          ))}
        </nav>
        
        <main style={{
          background: 'rgba(0, 0, 0, 0.4)',
          backdropFilter: 'blur(10px)',
          border: '1px solid rgba(255, 215, 0, 0.3)',
          borderRadius: '24px',
          padding: '32px',
          boxShadow: '0 0 50px rgba(255, 215, 0, 0.2)',
          position: 'relative'
        }}>
          <div style={{ position: 'relative', zIndex: 10 }}>
            {tab==='roulette-pro' && <RoulettePro onDone={refreshBalance}/>}
            {tab==='blackjack' && <Blackjack onDone={refreshBalance}/>}
            {tab==='baccarat' && <Baccarat onDone={refreshBalance}/>}
            {tab==='slots' && <Slots onDone={refreshBalance}/>}
            {tab==='crash' && <Crash onDone={refreshBalance}/>}
          </div>
        </main>
      </div>
      
      {/* Game History Modal */}
      {showHistory && <GameHistory onClose={() => setShowHistory(false)} />}
      
      </div>
    </>
  )
}

