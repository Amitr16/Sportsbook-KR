// API Configuration - Use sportsbook backend for shared authentication and wallet
const getApiUrl = () => {
  // Always use the current origin (sportsbook backend)
  return window.location.origin;
};

export const API_BASE_URL = getApiUrl();

// Make it available globally for backward compatibility
if (typeof window !== 'undefined') {
  window.CASINO_API = API_BASE_URL;
  console.log('Final API_BASE_URL:', API_BASE_URL); // Debug log
}
