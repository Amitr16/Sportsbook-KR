import React, { useState } from 'react';

const WalletManager = ({ onClose, onBalanceUpdate }) => {
  const [depositAmount, setDepositAmount] = useState('');
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  const handleDeposit = async () => {
    const amount = parseFloat(depositAmount);
    if (!amount || amount <= 0) {
      setMessage('Please enter a valid deposit amount');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`${window.CASINO_API}/casino/wallet/deposit`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-User-Id': 'demo-user'
        },
        body: JSON.stringify({ amount, currency: 'USD' })
      });

      if (response.ok) {
        const data = await response.json();
        setMessage(`✅ ${data.message}`);
        setDepositAmount('');
        onBalanceUpdate(); // Refresh balance
      } else {
        const error = await response.json();
        setMessage(`❌ ${error.detail || 'Deposit failed'}`);
      }
    } catch (error) {
      setMessage(`❌ Network error: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleWithdraw = async () => {
    const amount = parseFloat(withdrawAmount);
    if (!amount || amount <= 0) {
      setMessage('Please enter a valid withdrawal amount');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`${window.CASINO_API}/casino/wallet/withdraw`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-User-Id': 'demo-user'
        },
        body: JSON.stringify({ amount, currency: 'USD' })
      });

      if (response.ok) {
        const data = await response.json();
        setMessage(`✅ ${data.message}`);
        setWithdrawAmount('');
        onBalanceUpdate(); // Refresh balance
      } else {
        const error = await response.json();
        setMessage(`❌ ${error.detail || 'Withdrawal failed'}`);
      }
    } catch (error) {
      setMessage(`❌ Network error: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-gray-900 w-full max-w-md rounded-2xl border-4 border-yellow-600 overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-yellow-600 to-yellow-500 p-4 flex justify-between items-center">
          <h2 className="text-2xl font-bold text-black">💰 Wallet Manager</h2>
          <button
            onClick={onClose}
            className="bg-black text-white px-4 py-2 rounded-lg hover:bg-gray-800 transition-colors"
          >
            ✕ Close
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Deposit Section */}
          <div className="bg-green-900 bg-opacity-20 border-2 border-green-500 rounded-lg p-4">
            <h3 className="text-lg font-bold text-green-400 mb-3">💳 Deposit Funds</h3>
            <div className="flex gap-2">
              <input
                type="number"
                value={depositAmount}
                onChange={(e) => setDepositAmount(e.target.value)}
                placeholder="Enter amount"
                className="flex-1 px-3 py-2 bg-gray-800 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-green-500"
                min="0"
                step="0.01"
              />
              <button
                onClick={handleDeposit}
                disabled={loading || !depositAmount}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {loading ? '⏳' : 'Deposit'}
              </button>
            </div>
          </div>

          {/* Withdraw Section */}
          <div className="bg-red-900 bg-opacity-20 border-2 border-red-500 rounded-lg p-4">
            <h3 className="text-lg font-bold text-red-400 mb-3">💸 Withdraw Funds</h3>
            <div className="flex gap-2">
              <input
                type="number"
                value={withdrawAmount}
                onChange={(e) => setWithdrawAmount(e.target.value)}
                placeholder="Enter amount"
                className="flex-1 px-3 py-2 bg-gray-800 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-red-500"
                min="0"
                step="0.01"
              />
              <button
                onClick={handleWithdraw}
                disabled={loading || !withdrawAmount}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {loading ? '⏳' : 'Withdraw'}
              </button>
            </div>
          </div>

          {/* Quick Amount Buttons */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-gray-300">Quick Amounts:</h4>
            <div className="grid grid-cols-3 gap-2">
              {[10, 25, 50, 100, 250, 500].map(amount => (
                <button
                  key={amount}
                  onClick={() => {
                    setDepositAmount(amount.toString());
                    setWithdrawAmount(amount.toString());
                  }}
                  className="px-3 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition-colors text-sm"
                >
                  ${amount}
                </button>
              ))}
            </div>
          </div>

          {/* Message Display */}
          {message && (
            <div className={`p-3 rounded-lg text-sm ${
              message.includes('✅') 
                ? 'bg-green-900 bg-opacity-30 text-green-300 border border-green-500' 
                : 'bg-red-900 bg-opacity-30 text-red-300 border border-red-500'
            }`}>
              {message}
            </div>
          )}

          {/* Info */}
          <div className="text-xs text-gray-400 space-y-1">
            <div>• Deposits are instant and free</div>
            <div>• Withdrawals are processed immediately</div>
            <div>• All amounts are in USD</div>
            <div>• Starting balance: $1,000</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WalletManager;
