import React, { useState, useEffect } from 'react';

const GameHistory = ({ onClose }) => {
  const [history, setHistory] = useState([]);
  const [filter, setFilter] = useState('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchHistory();
  }, []);

  const fetchHistory = async () => {
    try {
      const response = await fetch(`${window.CASINO_API}/api/casino/history`, {
        credentials: 'include'
      });
      if (response.ok) {
        const data = await response.json();
        setHistory(data.history || []);
      } else {
        setHistory([]);
      }
    } catch (error) {
      console.error('Failed to fetch history:', error);
      setHistory([]);
    } finally {
      setLoading(false);
    }
  };

  const filteredHistory = history.filter(entry => {
    if (filter === 'all') return true;
    return entry.game_key === filter;
  });

  const formatDate = (timestamp) => {
    return new Date(timestamp).toLocaleString();
  };

  const getGameIcon = (gameKey) => {
    const icons = {
      'roulette': '🎰',
      'blackjack': '🃏',
      'baccarat': '🎴',
      'slots': '🎲',
      'crash': '🚀'
    };
    return icons[gameKey] || '🎮';
  };

  const getGameName = (gameKey) => {
    const names = {
      'roulette': 'Roulette',
      'blackjack': 'Blackjack',
      'baccarat': 'Baccarat',
      'slots': 'Slots',
      'crash': 'Crash'
    };
    return names[gameKey] || gameKey;
  };

  const getResultDisplay = (entry) => {
    if (entry.result_json) {
      const result = entry.result_json;
      
      if (entry.game_key === 'roulette') {
        return `Winning Number: ${result.spin?.pocket || 'N/A'}`;
      } else if (entry.game_key === 'blackjack') {
        return `Player: ${result.pv || 0} | Dealer: ${result.dv || 0}`;
      } else if (entry.game_key === 'baccarat') {
        return `Player: ${result.player_total || 0} | Banker: ${result.banker_total || 0}`;
      } else if (entry.game_key === 'slots') {
        return `Reels: ${result.reels?.join(' ') || 'N/A'}`;
      } else if (entry.game_key === 'crash') {
        return `Multiplier: ${result.multiplier || 'N/A'}x`;
      }
    }
    return 'N/A';
  };

  if (loading) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-gray-900 p-8 rounded-2xl text-center">
          <div className="text-2xl mb-4">⏳</div>
          <div className="text-white">Loading game history...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-gray-900 w-full max-w-4xl max-h-[80vh] rounded-2xl border-4 border-yellow-600 overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-yellow-600 to-yellow-500 p-4 flex justify-between items-center">
          <h2 className="text-2xl font-bold text-black">🎮 Game History</h2>
          <button
            onClick={onClose}
            className="bg-black text-white px-4 py-2 rounded-lg hover:bg-gray-800 transition-colors"
          >
            ✕ Close
          </button>
        </div>

        {/* Filters */}
        <div className="p-4 bg-gray-800">
          <div className="flex gap-2 flex-wrap">
            <button
              onClick={() => setFilter('all')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                filter === 'all' 
                  ? 'bg-yellow-500 text-black font-bold' 
                  : 'bg-gray-700 text-white hover:bg-gray-600'
              }`}
            >
              All Games
            </button>
            <button
              onClick={() => setFilter('roulette')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                filter === 'roulette' 
                  ? 'bg-yellow-500 text-black font-bold' 
                  : 'bg-gray-700 text-white hover:bg-gray-600'
              }`}
            >
              🎰 Roulette
            </button>
            <button
              onClick={() => setFilter('blackjack')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                filter === 'blackjack' 
                  ? 'bg-yellow-500 text-black font-bold' 
                  : 'bg-gray-700 text-white hover:bg-gray-600'
              }`}
            >
              🃏 Blackjack
            </button>
            <button
              onClick={() => setFilter('baccarat')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                filter === 'baccarat' 
                  ? 'bg-yellow-500 text-black font-bold' 
                  : 'bg-gray-700 text-white hover:bg-gray-600'
              }`}
            >
              🎴 Baccarat
            </button>
            <button
              onClick={() => setFilter('slots')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                filter === 'slots' 
                  ? 'bg-yellow-500 text-black font-bold' 
                  : 'bg-gray-700 text-white hover:bg-gray-600'
              }`}
            >
              🎲 Slots
            </button>
            <button
              onClick={() => setFilter('crash')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                filter === 'crash' 
                  ? 'bg-yellow-500 text-black font-bold' 
                  : 'bg-gray-700 text-white hover:bg-gray-600'
              }`}
            >
              🚀 Crash
            </button>
          </div>
        </div>

        {/* History List */}
        <div className="p-4 max-h-96 overflow-y-auto">
          {filteredHistory.length === 0 ? (
            <div className="text-center text-gray-400 py-8">
              <div className="text-4xl mb-4">📝</div>
              <div>No game history found</div>
              <div className="text-sm mt-2">Play some games to see your history here!</div>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredHistory.map((entry, index) => (
                <div
                  key={entry.id || index}
                  className={`p-4 rounded-lg border-2 transition-all ${
                    entry.payout > 0
                      ? 'border-green-500 bg-green-900 bg-opacity-20'
                      : 'border-red-500 bg-red-900 bg-opacity-20'
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <div className="flex items-center gap-3">
                      <div className="text-2xl">{getGameIcon(entry.game_key)}</div>
                      <div>
                        <div className="font-bold text-white">
                          {getGameName(entry.game_key)}
                        </div>
                        <div className="text-sm text-gray-300">
                          {formatDate(entry.created_at)}
                        </div>
                        <div className="text-sm text-gray-400">
                          {getResultDisplay(entry)}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className={`font-bold text-lg ${
                        entry.payout > 0 ? 'text-green-400' : 'text-red-400'
                      }`}>
                        {entry.payout > 0 ? '+' : ''}${entry.payout.toFixed(2)}
                      </div>
                      <div className="text-sm text-gray-400">
                        Stake: ${entry.stake.toFixed(2)}
                      </div>
                      {entry.ref && (
                        <div className="text-xs text-gray-500">
                          Ref: {entry.ref.substring(0, 8)}...
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Summary */}
        {filteredHistory.length > 0 && (
          <div className="p-4 bg-gray-800 border-t border-gray-700">
            <div className="flex justify-between text-sm">
              <div className="text-gray-300">
                Total Games: {filteredHistory.length}
              </div>
              <div className="text-gray-300">
                Total Won: ${filteredHistory.reduce((sum, entry) => sum + Math.max(0, entry.payout), 0).toFixed(2)}
              </div>
              <div className="text-gray-300">
                Total Lost: ${filteredHistory.reduce((sum, entry) => sum + (entry.payout <= 0 ? entry.stake : 0), 0).toFixed(2)}
              </div>
              <div className={`font-bold ${
                filteredHistory.reduce((sum, entry) => sum + (entry.payout - entry.stake), 0) >= 0
                  ? 'text-green-400'
                  : 'text-red-400'
              }`}>
                Net: ${filteredHistory.reduce((sum, entry) => sum + (entry.payout - entry.stake), 0).toFixed(2)}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default GameHistory;