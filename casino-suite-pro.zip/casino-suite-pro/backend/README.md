# Backend (Pro)
- Adds `/casino/history` for KPIs
- Adds `/ws/crash` WebSocket demo loop (per-connection)
Run: same as before.
